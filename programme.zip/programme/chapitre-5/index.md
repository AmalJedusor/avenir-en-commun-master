# Face à la guerre, instaurer l’indépendance de la France au service de la paix

> L'armée française est engagée dans un nombre sans précédent de conflits
> armés. Comment sortir de la logique de guerre ? Comment restaurer
> l'indépendance de la France pour préparer la paix ?

> Nous ne devons plus être à la remorque des folies impériales des
> États-Unis et de leur outil de tutelle militaire :
> l'OTAN (Organisation du traité de l'Atlantique nord).

> Nous sommes une nation universaliste. Notre vocation est à
> l'ONU (Organisation des Nations Unies) et dans la coopération
> privilégiée avec les pays émergents. Notre ancrage est en Méditerranée
> et avec les peuples francophones du continent africain, là ou va se
> façonner l'avenir. Au lieu de quoi nous sommes en guerre avec des buts
> imprécis et des alliances malsaines ! Mais qui s'occupe de préparer la
> paix plutôt que la guerre généralisée ? Nous !
