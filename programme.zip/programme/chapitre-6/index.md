# Face à la grande régression, choisir l’objectif du progrès humain

> Seuls le cours de bourse et le taux de profit intéressent l'oligarchie.
> Et les êtres humains ? Mieux vaudrait atteindre de nouveaux progrès
> humains dans notre société et proposer d'autres modèles de vie.

> Ne faudrait-il pas enfin s'alarmer pour notre système de santé quand
> l'espérance de vie recule ? Ne devrait-on pas se soucier de notre
> aptitude aux pratiques et aux créations culturelles émancipatrices
> plutôt que de laisser l'uniformisation, l'agression publicitaire et le
> consumérisme tout appauvrir ? Ne faut-il pas donner la priorité à
> l'éducation de notre nombreuse jeunesse et à cultiver de l'appétit pour
> les sciences quand on entre dans un monde de si haut niveau technique ?
> Et sait-on épanouir notre corps dans la pratique du sport quand celui-ci
> est à son tour annexé par l'obsession de l'argent ?

> Je crois qu'un projet de vie humaine est mieux réussi par les bonheurs
> simples qui viennent de ce genre de préoccupations, plutôt que par la
> grotesque course à l'accumulation. La vraie richesse n'est pas celle de
> l'argent. Être milliardaire est immoral. Vouloir le devenir est une
> névrose du cœur.
