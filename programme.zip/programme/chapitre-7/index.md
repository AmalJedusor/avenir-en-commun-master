# Face au déclinisme, porter la France aux frontières de l’Humanité

> La mer, l'espace, le monde du numérique et du virtuel sont les nouvelles
> frontières de l'humanité. Les Français excellent dans ces domaines
> d'avenir. Mais l'ambition politique est absente ! Comment porter la
> France aux avant-postes de l'humanité pour contribuer à l'essor
> universel ?

> Je connais aussi la force d'entraînement des grands enthousiasmes
> collectifs. La France est le deuxième territoire maritime du monde, et
> la deuxième Nation pour la cotisation individuelle à la conquête de
> l'espace ! Sans parler du génie français particulièrement fécond dans
> l'univers du numérique et du virtuel.

> Voilà qui fait de nous un peuple avec une responsabilité particulière et
> enthousiasmante ! Ici se trouvent d'immenses gisements d'emplois,
> d'inventions et de progrès écologiques pour la France et la civilisation
> humaine.
