# Face à la crise européenne, sortir des traités européens

> L'Europe de nos rêves est morte. L'Union actuelle est seulement un
> marché unique et les peuples sont soumis à la dictature des banques et
> de la finance. Comment stopper ce cauchemar ?

> Nous devons sortir des traités européens qui nous font obligation de
> mener des politiques d'austérité, d'abolir l'action de l'État et les
> investissements publics et nous empêchent ainsi de préparer la grande
> bifurcation écologique. Tout cela au prétexte d'une dette dont tout le
> monde sait qu'elle ne peut être payée dans aucun pays.

> Notre indépendance d'action et la souveraineté de nos décisions ne
> doivent donc plus être abandonnées aux obsessions idéologiques de la
> Commission européenne ni à la superbe du gouvernement allemand.
