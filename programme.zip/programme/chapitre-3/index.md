# Face à la crise climatique, la planification écologique

> Le changement climatique a commencé et s'accélère. Il menace de détruire
> le seul écosystème compatible avec la vie humaine. Comment empêcher la
> catastrophe ?

> La transition énergétique est vitale ! Il s'agit de répondre ici et
> maintenant à l'intérêt général humain face au dérèglement climatique. Ce
> grand changement doit modifier tous les compartiments de la vie de notre
> société par une planification écologique.

> Nous savons bien que tout cela nécessite des investissements massifs,
> une abondante main-d'œuvre qualifiée et bien payée. Mais l'exigence
> écologique ne peut être réduite à des proclamations et des mesures qui
> épargnent le système. La finance n'en veut pas : elle préfère les grands
> rendements de la spéculation. La définanciarisation de l'économie est
> une condition incontournable de la transition écologique.
