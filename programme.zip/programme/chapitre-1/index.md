# Face à la crise démocratique, convoquer l’assemblée constituante de la 6e République

> Tout commence par le pouvoir des citoyens. Comment rendre le pouvoir
> au peuple, en finir avec le système de la caste médiatico-politique et
> de la monarchie présidentielle ?
>
> C'est l'ère du peuple qui doit commencer ! La révolution citoyenne à
> laquelle je crois est le moyen pacifique et démocratique de tourner la
> page de la tyrannie de l'oligarchie financière et de la caste qui est
> à son service.
>
> Ce sera la tâche d'une Assemblée constituante, convoquée pour changer
> de fond en comble la Constitution, abolir la monarchie présidentielle
> et restaurer le pouvoir de l'initiative populaire. Je voudrais être le
> dernier président de la 5^e^ République et rentrer chez moi sitôt que
> la nouvelle Constitution aura été adoptée par le peuple français. La
> 6ème République commencera et ce sera une refondation de la France
> elle-même.
>
> Jean-Luc Mélenchon
