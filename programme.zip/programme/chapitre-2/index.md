# Face au chômage et à l’urgence sociale, partager les richesses, mettre au pas la finance

> La France est le pays d'Europe qui compte le plus de millionnaires (plus
> de deux millions de personnes). Conséquences : la pauvreté gagne du
> terrain, le chômage se généralise, l'État se disloque, les services
> publics reculent. Comment sortir de cette spirale ?

> L'appauvrissement des classes moyennes et les misères du peuple n'ont
> rien de fatal. Notre pays n'a jamais été aussi riche. Il est donc temps
> de se donner les moyens de partager la charge de travail nécessaire.

> Protégeons de la finance les salariés et la production en France.
> Révolutionnons les impôts pour que tout le monde paye, et que chacun le
> fasse selon ses moyens réels.
